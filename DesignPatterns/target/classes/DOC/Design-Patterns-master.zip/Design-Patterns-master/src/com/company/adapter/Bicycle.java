package com.company.adapter;

public class Bicycle {

    public void pedal() {
        System.out.println("Bike start to move ");
    }

    public void stop() {
        System.out.println("Bike Stopped");
    }

    public void ringBell() {
        System.out.println("Ring ring...");
    }
}
