package com.company.command;

public class MediaPlayer {
    public void turnOn() {
        System.out.println("MediaPlayer is turning ON");
    }

    public void turnOff() {
        System.out.println("MediaPlayer is turning OFF");
    }
}
