package com.company.adapter;

public interface Vehicle {
    void accelerate();
    void pushBreak();
    void soundHorn();
}
