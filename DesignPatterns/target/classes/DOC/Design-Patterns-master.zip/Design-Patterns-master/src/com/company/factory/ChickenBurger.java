package com.company.factory;

public class ChickenBurger extends Sandwich{
    public ChickenBurger(){
        setName("Chicken Burger");
        setCalories(150);
    }
}
