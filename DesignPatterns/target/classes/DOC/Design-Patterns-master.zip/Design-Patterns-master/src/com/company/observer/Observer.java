package com.company.observer;

public interface Observer {

    void update(String message);
}
