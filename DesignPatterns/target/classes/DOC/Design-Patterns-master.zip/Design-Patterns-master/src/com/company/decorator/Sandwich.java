package com.company.decorator;

public interface Sandwich {
    double getCost();
    String getDescription();
}
