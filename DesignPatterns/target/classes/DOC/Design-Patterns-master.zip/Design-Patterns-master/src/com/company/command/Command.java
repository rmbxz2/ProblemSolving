package com.company.command;

public interface Command {
    void execute();
}
