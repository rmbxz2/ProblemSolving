package com.company.factory;

public class CheeseBurger extends Sandwich {
    public CheeseBurger(){
        setName("Cheese Burger");
        setCalories(250);
    }
}
