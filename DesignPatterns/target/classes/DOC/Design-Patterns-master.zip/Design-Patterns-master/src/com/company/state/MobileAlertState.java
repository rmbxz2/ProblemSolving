package com.company.state;

public interface MobileAlertState {
    void alert();
}
