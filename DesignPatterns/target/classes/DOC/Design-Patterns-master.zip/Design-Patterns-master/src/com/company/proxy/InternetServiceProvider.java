package com.company.proxy;

public interface InternetServiceProvider {

    String serveSite(String url);
}
