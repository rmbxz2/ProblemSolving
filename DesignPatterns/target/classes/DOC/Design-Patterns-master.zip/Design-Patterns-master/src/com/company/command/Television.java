package com.company.command;

public class Television {
    public void turnOn() {
        System.out.println("TV is turning ON");
    }

    public void turnOff() {
        System.out.println("TV is turning OFF");
    }
}
